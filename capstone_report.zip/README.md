This data is form the Official NIH 

Website: https://ceb.nlm.nih.gov/repositories/malariadatasets/. 

The data is open � sourced and can be downloading for education purpose with no
citation.

Project Proposal Review Link:

https://review.udacity.com/#!/reviews/1704639